import com.opencsv.CSVReader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.stream.IntStream;

public class problem {

    protected static String name = "Test Suite Minimization";

    protected static int dimension;

    protected static int [] costs;

    protected static String path="C:\\Users\\User\\IdeaProjects\\SSA\\src\\dataset\\XML-Security.csv";

    protected static double[][] constraints;

    //            {
//            {1,  1,  0,  1,  0,  0,  1,  0,  0},
//            {1,  1,  0,  1,  0,  0,  1,  0,  0},
//            {1,  0,  0,  1,  1,  1,  1,  0,  0},
//            {0,  1,  0,  1,  0,  1,  1,  0,  0},
//            {1,  1,  0,  1,  1,  1,  1,  1,  0},
//            {1,  0,  1,  1,  0,  1,  1,  1,  0},
//            {0,  0,  0,  1,  1,  1,  1,  0,  0},
//            {0,  0,  1,  1,  1,  0,  1,  0,  0},
//            {0,  0,  0,  1,  0,  1,  1,  0,  0},
//            {1,  1,  0,  1,  1,  1,  1,  0,  0},
//            {0,  1,  0,  1,  0,  1,  1,  0,  0},
//            {0,  1,  0,  0,  0,  1,  1,  0,  0},
//            {1,  0,  0,  0,  0,  1,  0,  0,  0},
//            {0,  0,  0,  0,  0,  1,  0,  1,  0},
//            {0,  0,  0,  0,  1,  1,  0,  1,  0},
//            {0,  0,  0,  0,  1,  1,  0,  0,  0},
//            {0,  0,  0,  0,  1,  1,  0,  0,  0},
//            {0,  0,  1,  0,  0,  0,  0,  0,  0},
//            {0,  0,  1,  0,  0,  0,  0,  0,  1},
//            {0,  0,  0,  0,  0,  0,  0,  0,  1}
//        };

    public static void main123() throws Exception {
        String[][] matrix=readFile(path);
        double [][] doubleMatrix=new double[matrix.length][matrix[0].length];

        dimension=doubleMatrix.length;
        costs = new int [dimension];

        for (int i=0;i<matrix.length;i++){
            for (int k=0;k<matrix[0].length;k++)
            {
                doubleMatrix[i][k]=Double.parseDouble(matrix[i][k]);
            }

            double[] TestcaseFit=Objective_Function.func(doubleMatrix[i]);
            costs[i]= (int)(TestcaseFit[0]);
        }
        constraints =transposeMatrix(doubleMatrix);

        System.out.println("XML Security data set Number of columns ="+doubleMatrix[0].length+" Rows = "+doubleMatrix.length);
    }

    private static String[][] readFile(String filename) throws Exception {
        try (CSVReader reader = new CSVReader(new BufferedReader(
                new FileReader(filename)));) {

            List<String[]> lines = reader.readAll();
            return lines.toArray(new String[lines.size()][]);
        }

    }

    public static double[][] transposeMatrix(double[][] arr) {
        double[][] transposed = new double[arr[0].length][arr.length];
        IntStream.range(0, arr.length)
                .forEach(i -> IntStream.range(0, arr[0].length)
                        .forEach(j -> transposed[j][i] = arr[i][j]));
        return transposed;
    }




    protected static int optimal = 100;
}
