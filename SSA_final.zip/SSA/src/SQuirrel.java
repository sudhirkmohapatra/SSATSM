
public class SQuirrel {
    SQuirrel() {
        for (int j = 0; j < ParaMint.D; j++) {
            ParaMint.iPosition[j] = StdRandom.uniform(2);
        }
    }

    void update_best_sol() {
        System.arraycopy(ParaMint.iPosition, 0, ParaMint.iBestPosition, 0, ParaMint.iPosition.length);
    }

    float rowCovering() {
        float total = 0;
        for (int j = 0; j < ParaMint.D; j++) {
            total += ParaMint.iPosition[j] * ParaMint.TcaseFit[j];
        }
        return total;
    }

    float updateSolution(int iter) {
        float total = 0;
        for (int j = 0; j < ParaMint.D; j++) {
            if (ParaMint.TcaseFit[j]>1)
            {
                total += ParaMint.iBestPosition[j] * ParaMint.TcaseFit[j];
            }
            else{ParaMint.iBestPosition[j]=0; }

        }
        if (total <= 100)
        {
            ParaMint.elapseTime=System.currentTimeMillis();
            ParaMint.stop_criteria = false;
        }
        if (total <ParaMint.minCostoCover)
        {
            ParaMint.minCostoCover = total;
            ParaMint.lastIteration=(iter+1);
            ParaMint.elapseTime=System.currentTimeMillis();
            System.arraycopy(ParaMint.iBestPosition, 0, ParaMint.iBestCover, 0, ParaMint.iBestPosition.length);
        }
        return total;
    }

    boolean iCandidateChecker() {
        int total = 0;
        int i = 0;
        boolean candidate = true;
        while (i < problem.constraints.length && candidate) {
            for (int j = 0; j < ParaMint.D; j++) {
                total += ParaMint.iPosition[j] * problem.constraints[i][j];
            }
            candidate = (total >= 1);
            total = 0;
            i++;
        }
        return candidate;
    }

    void repairing() {
        int worstCI = 0, total;
        double worstC;
        double CL[] = new double[ParaMint.D];

        for (int j = 0; j < CL.length; j++) {
            total = 0;
            for (int i = 0; i < problem.constraints.length; i++) {
                total += problem.constraints[i][j];
            }
          if (total!=0) {
            CL[j] = (CL.length / total);

            }
        }

        do {
            worstC = CL[worstCI];
            for (int j = 0; j < CL.length; j++) {
                if (CL[j] < worstC) {
                    worstC = CL[j];
                    worstCI = j;
                }
            }

            ParaMint.iPosition[worstCI] = 1;
            CL[worstCI] = Double.MAX_VALUE;
        } while (!iCandidateChecker());
    }

    void copy_solution(Object object) {
        if (object instanceof SQuirrel) {
            System.arraycopy(ParaMint.iPosition, 0, ParaMint.iPosition, 0, ParaMint.D);
            System.arraycopy(ParaMint.iBestPosition, 0, ParaMint.iBestPosition, 0, ParaMint.D);
        }
    }
}
