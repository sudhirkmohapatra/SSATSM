import java.text.DecimalFormat;
import java.util.ArrayList;

public class ParaMint {
    static int N;
    static int D;
    static int Maxiter;
    static double Lower;
    static double Upper;
    static double Gc;
    static double Pdp;
    static double CL;
    static double CD;
    static double hg;

    static int N_HNT;
    static int N_ANT;
    static int N_NORMT;

    static double[][] FS;
    static double[][] DMatrix;
    static double[] Sc;
    static double[][] FS_HNT;
    static double[][] FS_ANT;
    static double[][] newFS_ANT;
    static double[][] FS_NORMT;
    static double[][] newFS_NORMT;
    static double Smin;
    static double sf;

    static double[][] out;
    static int[] TcaseFit;
    static int[] iPosition;
    static DecimalFormat to;
    static int[] iBestCover;
    static int lastIteration;
    static double[] fitnessD;
    static double[][] rowDATA;
    static double[] fitnessFS;
    static float minCostoCover;
    static int[] iBestPosition;
    static boolean stop_criteria;
    static SQuirrel sQuirrelSet, isQuirrel;
    static Long initialTime,elapseTime;
    static ArrayList<SQuirrel> tSquirrels;
    static final String GREEN = "\033[0;32m";
    static final String ANSI_RESET = "\u001B[0m";
    static final String ANSI_RED = "\u001B[31m";
    static final String ANSI_PURPLE = "\u001B[35m";
    static final String ANSI_YELLOW = "\u001B[33m";
    static final String ANSI_BLUE = "\u001B[34m";

    static double[][] tmpFS_HNT;
    static double[][] tmpFS_ANT;
    static double[][] tmpFS_NORMT;
    static String suite="";
    static String NoTcase="";

    public ParaMint(int iN,int iD,double iLower,double iUpper, int iMaxiter)
    {
        N=iN;
        Lower=iLower;
        Upper=iUpper;
        Maxiter=iMaxiter;
        D=iD;

        Gc=1.9;
        hg=8.0;
        sf=18.0;
        Pdp=0.01;
        N_HNT=1;
        N_ANT=3; //(int)((double)N*0.06);
        N_NORMT=D-N_ANT-N_HNT;
        FS=new double[D][N];
        FS_HNT=new double[N_HNT][N];
        Sc=new double[N_ANT];
        FS_ANT=new double[N_ANT][N];
        newFS_ANT=new double[N_ANT][N];
        FS_NORMT=new double[N_NORMT][N];
        newFS_NORMT=new double[N_NORMT][N];

        minCostoCover=0.0f;
        stop_criteria=true;
        TcaseFit=new int[D];
        iPosition=new int[D];
        out=new double[5][D];
        iBestCover=new int[D];
        fitnessD =new double[D];
        fitnessFS=new double[D];
        iBestPosition=new int[D];
        DMatrix =new double[D][N];
        rowDATA =new double[D][N];
        to = new DecimalFormat("#.###");
    }
}