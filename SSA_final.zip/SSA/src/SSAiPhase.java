import java.util.*;
import java.util.stream.IntStream;

public class SSAiPhase
{
	SQuirrel sQ=new SQuirrel();

			double[][] sort_and_index(double[] A) {
			ArrayList<Double> B=new ArrayList<Double>();
			for(int i=0;i<A.length;i++)
			{B.add(A[i]);}
			ArrayList<Double> nstore=new ArrayList<Double>(B);
			Collections.sort(B);
			double[] ret=new double[B.size()];
			Iterator<Double> iterator=B.iterator();
			int ii=0;
			while(iterator.hasNext())
			{ret[ii]=iterator.next().doubleValue();ii++;}
			int[] indexes=new int[B.size()];
			for(int n=0;n<B.size();n++)
			{indexes[n]=nstore.indexOf(B.get(n));}
			double[][] outt=new double[2][B.size()];
			for(int i=0;i<B.size();i++)
			{outt[0][i]=ret[i];outt[1][i]=indexes[i];}
			return outt;
			}

			double[][] sorted(double[][] TT) {
			int mm=TT.length;
			int nn=TT[0].length;
			double[][] TNEW=new double[mm][nn];
			double[] fitnessTT=new double[mm];
			double [] iPOPFit;
			for(int i=0;i<mm;i++) {
			iPOPFit= Objective_Function.func(TT[i]);
			fitnessTT[i]=iPOPFit[0];
			}
			double[][] FF=sort_and_index(fitnessTT);
			for(int i=0;i<mm;i++)
			{
				for(int j=0;j<nn;j++)
				 {
				 	TNEW[i][j]=TT[(int)FF[1][i]][j];
				 }
			}

			return TNEW;
			}

			double dgg() {return 0.5+(1.11-0.5)*Math.random();}

			double[][] randperm(double a[][]) {
			double y[][]=new double[a.length][a[0].length];
			double[] sw=new double[a[0].length];
			for(int i=0;i<a.length;i++)
			{y[i]=a[i];}
			int m=a.length;
			int rp=0;
			for(int i=0;i<m-1;i++)
			{rp=(int)((m-i)*Math.random()+i);sw=y[i];
			y[i]=y[rp];y[rp]=sw;}
			return y;
			}

			public static double norm(double v[]) {
			// vector norm
			double total=0;;
			for(int i=0;i<v.length;i++)
			{total+=v[i]*v[i];}
			return Math.sqrt(total);
			}

			double[][] boundary(double[][] XX) {
			int NN=XX.length;
			int DD=XX[0].length;
			for(int i=0;i<NN;i++){
			for(int j=0;j<DD;j++){
			if((XX[i][j]<ParaMint.Lower)||(XX[i][j]>ParaMint.Upper))
			{
			XX[i][j]=BinarizationStrategy.toBinary(XX[i][j]);
			//Lower+((Upper-Lower)*Math.random());
			}
			} }
			return XX;
			}

			double[][] Update(double[][] TT, double[][] newTT) {
			int DD=TT[0].length;
			int NN=TT.length;
			double [] inewTT,iTT;
			for(int i=0;i<NN;i++){
			inewTT= Objective_Function.func(newTT[i]);
			iTT= Objective_Function.func(TT[i]);
			if(inewTT[0]<iTT[0]) {
			for(int j=0;j<DD;j++){
			TT[i][j]=newTT[i][j];
			}
			}
			}
			return TT;
			}

			public static double[] substract(double[] left,double[] right) {
			//addition of two vectors
			int n1=left.length;
			int n2=right.length;
			int nMax;
			int i;
			if(n1>=n2) nMax=n1;
			else       nMax=n2;
			double b[];
			b=new double[nMax];
			for(i=0;i<n1;i++)
			{b[i]=b[i]+left[i];}
			for(i=0;i<n2;i++)
			{b[i]=b[i]-right[i];}
			return b;
			//end of vector substraction method
			}

			double logGamma(double x) {
			double tmp = (x - 0.5) * Math.log(x + 4.5) - (x + 4.5);
			double ser = 1.0 + 76.18009173    / (x + 0)   - 86.50532033    / (x + 1)
			+ 24.01409822    / (x + 2)   -  1.231739516   / (x + 3)
			+  0.00120858003 / (x + 4)   -  0.00000536382 / (x + 5);
			return tmp + Math.log(ser * Math.sqrt(2 * Math.PI));
			}

			double gamma(double x) { return Math.exp(logGamma(x)); }

			double[] Levy() {
			double beta=1.5;
			double sigma=Math.pow((gamma(1+beta)*Math.sin(Math.PI*beta/2)/(gamma((1+beta)/2)*beta*Math.pow(2,((beta-1)/2)))),(1/beta));
			Random rnd=new Random();
			double[] u=new double[ParaMint.N];
			double[] v=new double[ParaMint.N];
			double[] step=new double[ParaMint.N];
			for(int j=0;j<ParaMint.N;j++)
			{u[j]=rnd.nextGaussian()*sigma;}
			for(int j=0;j<ParaMint.N;j++)
			{v[j]=rnd.nextGaussian();}
			for(int j=0;j<ParaMint.N;j++)
			{step[j]=u[j]/(Math.pow(Math.abs(v[j]),(1.0/beta)));}
			return step;
			}

			private void Candidate_SolChecker(int iter) {
			int i;
			ParaMint.sQuirrelSet = new SQuirrel();
			ParaMint.tSquirrels = new ArrayList<>();
			for (i = 0; i < ParaMint.N; i++) {
				ParaMint.isQuirrel = new SQuirrel();
				if (!ParaMint.isQuirrel.iCandidateChecker()) {
					ParaMint.isQuirrel.repairing();
				}
				ParaMint.isQuirrel.update_best_sol();
				ParaMint.tSquirrels.add(ParaMint.isQuirrel);
			}
			ParaMint.sQuirrelSet.copy_solution(ParaMint.tSquirrels.get(0));
			for (i = 1; i < ParaMint.N; i++) {
				if (ParaMint.tSquirrels.get(i).updateSolution(iter)< ParaMint.sQuirrelSet.updateSolution(iter)) {
					ParaMint.sQuirrelSet.copy_solution(ParaMint.tSquirrels.get(i));
				}
			}
			}

			private void optimalTestSuite() {
			System.out.print("Optimized Test suite [ ");
			for (int i = 0; i<ParaMint.D; ++i) {
				//System.out.print("" + (int) out[2][i] + " ");
				if (ParaMint.iBestCover[i]==1){
					System.out.print("T" + (i+1) + " ");
				}
				if (ParaMint.iBestCover[i]==0){
					System.out.print("" + 0 + " ");
				}
			}
			System.out.println(" ]");
			}

			private void iterationInfo() {
			System.out.println(ParaMint.ANSI_RED +"No of Test cases: " + ParaMint.NoTcase);
			System.out.println(ParaMint.ANSI_RED +"Global_Min Best = " + ParaMint.out[0][0]);
			System.out.println("Exact Coverage     = " + ParaMint.out[1][3]);
			System.out.println("Coverage Deviation = " + ParaMint.out[1][4]);
			System.out.println("Best Solution at Iteration = " + ParaMint.lastIteration);
			System.out.println("Suite Detection Capability = " + ParaMint.to.format(ParaMint.out[0][5])+ ParaMint.ANSI_RESET);
			}

			private void iDIMFitCost() {
			double total=0.0D;
			// best Dimension individuals cost
			System.out.print("Suite Fitness[ ");
			for (int i = 0; i < ParaMint.D; ++i) {
				total=total+ ParaMint.TcaseFit[i];
				System.out.print("" + (int) ParaMint.TcaseFit[i] + " ");
			}
			System.out.println(" ]");
			ParaMint.out[0][5]=((total/100)/(double) ParaMint.D);
			}

			private void line(){
			System.out.println("____________________________________________");
			}

			public static double[][] transposeMatrix(double[][] arr) {
			double[][] transposed = new double[arr[0].length][arr.length];
			IntStream.range(0, arr.length)
					.forEach(i -> IntStream.range(0, arr[0].length)
							.forEach(j -> transposed[j][i] = arr[i][j]));
			return transposed;
			}

			// Random initialization, Fitness evaluation, Sorting, declaration and random selection phase

			private void init() {

				ParaMint.rowDATA =problem.constraints;
				ParaMint.DMatrix=transposeMatrix(ParaMint.rowDATA);
				ParaMint.FS=ParaMint.DMatrix;

				// Random Position for Population
				//			System.out.println("RowData matrix");
				for (int i = 0; i < ParaMint.D; ++i) {
				double [] FS_FIT= Objective_Function.func(ParaMint.FS[i]);
				ParaMint.fitnessFS[i] = FS_FIT[0];
				//				System.out.println(""+Arrays.toString(ParaMint.FS[i])+"  "+ParaMint.to.format(ParaMint.fitnessFS[i]));
				}

				// Original 2D Matrix, its fitness and traversing the array

//				System.out.println("TCM matrix");
				for(int i=0;i<ParaMint.D;i++) {
					double[] DIM_FIT = Objective_Function.func(ParaMint.DMatrix[i]);
					ParaMint.fitnessD[i] = DIM_FIT[0];
					ParaMint.TcaseFit[i] = (int) (ParaMint.fitnessD[i]);
					ParaMint.minCostoCover += ParaMint.fitnessD[i];
					//				System.out.println(""+Arrays.toString(ParaMint.DMatrix[i])+"  "+ParaMint.to.format(ParaMint.TcaseFit[i])+"\t T"+(i+1));}

					// Sorting the 2D Matrix by squirrel fitness then display the matrix with fitness
				}
				ParaMint.FS=sorted(ParaMint.FS);
				//				System.out.println("Sorted matrix");
//				for(int i=0;i<ParaMint.D;i++) {
//				double [] FS_SORT_FIT= Objective_Function.func(ParaMint.FS[i]);
//								System.out.println(""+Arrays.toString(ParaMint.FS[i])+"   "+ParaMint.to.format(FS_SORT_FIT[0]));
//				}

				// // Assign squirrel to Hickory tree

				for(int i=0;i<ParaMint.N;i++){ParaMint.FS_HNT[0][i]=ParaMint.FS[0][i]; }


				// // Assign squirrel to Accron tree

				for(int i=0;i<ParaMint.N_ANT;i++)
				 {
				   for(int j=0;j<ParaMint.N;j++)
					 {
					  ParaMint.FS_ANT[i][j]=ParaMint.FS[1+i][j];
				   }
				 }

				// // Assign squirrel to Normal tree

			for(int i=0;i<ParaMint.N_NORMT;i++)
			 {
			    for(int j=0;j<ParaMint.N;j++)
			 	 {
					ParaMint.FS_NORMT[i][j]=ParaMint.FS[ParaMint.N_ANT+1+i][j];	// Assign squirrel to Normal tree
				}
			}

			System.out.println(ParaMint.ANSI_RED+"________iCost of TS___"+ParaMint.to.format(ParaMint.minCostoCover)
			+"______________"+ParaMint.ANSI_RESET);
			}

			//Generate new locations and iterative phase of Squirrel search algorithm until stopping criteria meets.

			private double[][] solution() {
			init();
			int iter=1;

			while(iter<ParaMint.Maxiter && ParaMint.stop_criteria)
			{
			Candidate_SolChecker(iter); // check squirrel candidate solution

				for(int i = 0; i < ParaMint.N; ++i)
				{
					if (ParaMint.tSquirrels.get(i).rowCovering() < ParaMint.tSquirrels.get(i).updateSolution(iter))
  					  {
						ParaMint.tSquirrels.get(i).update_best_sol();
					   }
					if (ParaMint.tSquirrels.get(i).updateSolution(iter)< ParaMint.sQuirrelSet.updateSolution(iter))
					  {
						ParaMint.sQuirrelSet.copy_solution(ParaMint.tSquirrels.get(i));
					  }
					if (!ParaMint.tSquirrels.get(i).iCandidateChecker())
					  {
						ParaMint.tSquirrels.get(i).repairing();
					  }
				}

			ParaMint.Smin=(10e-6)/Math.pow(365,((double)iter/((double)ParaMint.Maxiter/2.5)));

			for(int i=0;i<ParaMint.N_ANT;i++)
			{
				if(Math.random()>ParaMint.Pdp)
			  	 {
					for(int j=0;j<ParaMint.N;j++)
					 {
				  	   ParaMint.newFS_ANT[i][j]=ParaMint.FS_ANT[i][j]+dgg()*ParaMint.Gc*(ParaMint.FS_HNT[0][j]-ParaMint.FS_ANT[i][j]);
					 }
				 }
				else
				{
					for(int j=0;j<ParaMint.N;j++){
					ParaMint.newFS_ANT[i][j]=ParaMint.Lower+(ParaMint.Upper-ParaMint.Lower)*Math.random();
					}
				}
			}

			ParaMint.newFS_ANT=boundary(ParaMint.newFS_ANT);

			for(int i = 0; i< ParaMint.N_NORMT/2; i++)
			 {
				if(Math.random()> ParaMint.Pdp)
				{
				double[] levy=Levy();
				for(int j=0;j<ParaMint.N;j++) {
				ParaMint.newFS_NORMT[i][j]=ParaMint.FS_NORMT[i][j]+dgg()* ParaMint.Gc*(ParaMint.FS_ANT[(int)Math.floor((((double) ParaMint.N_ANT)*Math.random()))][j]- ParaMint.FS_NORMT[i][j]);
				}
				}
				else
				{
					for(int j=0;j<ParaMint.N;j++) {
					ParaMint.newFS_NORMT[i][j]= ParaMint.Lower+(ParaMint.Upper- ParaMint.Lower)*Math.random();}
				}
			}

			for(int i = ParaMint.N_NORMT/2; i< ParaMint.N_NORMT; i++) {
			if(Math.random()> ParaMint.Pdp)
			{
			for(int j=0;j<ParaMint.N;j++){
			ParaMint.newFS_NORMT[i][j]= ParaMint.FS_NORMT[i][j]+dgg()* ParaMint.Gc*(ParaMint.FS_HNT[0][j]- ParaMint.FS_NORMT[i][j]);
			}
			}
			else
			{
				for(int j=0;j<ParaMint.N;j++)
				  {
					ParaMint.newFS_NORMT[i][j]= ParaMint.Lower+(ParaMint.Upper- ParaMint.Lower)*Math.random();
				  }
			}
			}

			ParaMint.newFS_NORMT=boundary(ParaMint.newFS_NORMT);


			ParaMint.FS_NORMT=Update(ParaMint.FS_NORMT, ParaMint.newFS_NORMT);
			ParaMint.FS_ANT=Update(ParaMint.FS_ANT, ParaMint.newFS_ANT);

			for(int i=0;i<ParaMint.N;i++)
			 {
			  	ParaMint.FS[0][i]= ParaMint.FS_HNT[0][i];
			 }
			for(int i = 0; i< ParaMint.N_ANT; i++)
			 {
				for(int j=0;j<ParaMint.N;j++)
				 {
				   ParaMint.FS[1+i][j]= ParaMint.FS_ANT[i][j];
				}
			 }

			for(int i = 0; i< ParaMint.N_NORMT; i++)
			 {
				for(int j=0;j<ParaMint.N;j++)
				  {
					ParaMint.FS[ParaMint.N_ANT+1+i][j]= ParaMint.FS_NORMT[i][j];
				}
			}

			for(int i = 0; i< ParaMint.N_ANT; i++)
			 {
				ParaMint.Sc[i]=norm(substract(ParaMint.FS_ANT[i], ParaMint.FS_HNT[0]));
				if(ParaMint.Sc[i]< ParaMint.Smin)
				  {
				double[] levy=Levy();
			 	 for(int j=0;j<ParaMint.N;j++){
					ParaMint.FS[i][j]= ParaMint.Lower+levy[j]*(ParaMint.Upper- ParaMint.Lower);
					ParaMint.iPosition[i]=(int)(ParaMint.FS[i][j]);
				 }
			}
			}

			ParaMint.FS=boundary(ParaMint.FS);
			ParaMint.FS=sorted(ParaMint.FS);

			for(int i=0;i<ParaMint.N;i++)
			  {
				ParaMint.FS_HNT[0][i]= ParaMint.FS[0][i];
			  }

			for(int i = 0; i< ParaMint.N_ANT; i++)
			 {
				for(int j=0;j<ParaMint.N;j++)
				  {
					ParaMint.FS_ANT[i][j]= ParaMint.FS[1+i][j];
				 }
			}

			for(int i = 0; i< ParaMint.N_NORMT; i++)
			 {
				for(int j=0;j<ParaMint.N;j++)
			     {
					ParaMint.FS_NORMT[i][j]= ParaMint.FS[ParaMint.N_ANT+1+i][j];
				 }
			 }

			iter++;

			}

				ParaMint.out[0][0]=ParaMint.minCostoCover;
				ParaMint.out[1][1] = ParaMint.N;
				ParaMint.out[1][2] = problem.optimal;
				ParaMint.out[1][3] = sQ.updateSolution(iter);
				ParaMint.out[1][4] = (sQ.updateSolution(iter)-ParaMint.out[1][2]);

				//  Best position of individuals
				for (int i = 0; i < ParaMint.D; ++i) { ParaMint.out[2][i] = ParaMint.TcaseFit[i]; }

			//  update Hickory tree with best solution
				int noOfC=0;
				for (int i = 0; i<ParaMint.D; ++i){if (ParaMint.iBestCover[i]==1){ noOfC++;ParaMint.suite+="T"+i+", ";} }
				update_tree_sol(noOfC); ParaMint.NoTcase+=""+noOfC;
				ParaMint.tmpFS_HNT=new double[ParaMint.N_HNT][ParaMint.N];
				ParaMint.tmpFS_ANT=new double[ParaMint.N_ANT][ParaMint.N];
				ParaMint.tmpFS_NORMT=new double[ParaMint.N_NORMT][ParaMint.N];
				noOfC=0;

			return ParaMint.out;
			}

			private void update_tree_sol(int noOfC) {
			if (ParaMint.D>=50){
				ParaMint.N_HNT=noOfC;
				ParaMint.N_ANT=(int)((double)ParaMint.D*0.06);
				ParaMint.N_NORMT=ParaMint.D- ParaMint.N_ANT- ParaMint.N_HNT;
			}
			if (ParaMint.D<50 && ParaMint.D>=4)
			{
				ParaMint.N_HNT=noOfC;
				ParaMint.N_ANT=3;
				ParaMint.N_NORMT=ParaMint.D- ParaMint.N_ANT- ParaMint.N_HNT;
			}

	}

			private void DisplayOptimalSolution() {
				int HT_counter=0,tmpT_counter=0,NAT=ParaMint.N_ANT+ParaMint.N_NORMT;
				double [][] tempTree=new double[NAT][ParaMint.N];
				double [] FS_ANT_FIT,FS_NORMT_FIT,FS_HNT_FIT;
				for (int i = 0; i<ParaMint.D; ++i){
					if (ParaMint.iBestCover[i]==1)
					 {
						  for(int j=0;j<ParaMint.N;j++)
						   {
						   	ParaMint.tmpFS_HNT[HT_counter][j]=ParaMint.DMatrix[i][j]; 	 // Copy optimal solution to Hickory tree
						   }
						  HT_counter++;
					  }
					if (ParaMint.iBestCover[i]==0)
					 {
						 for(int j=0;j<ParaMint.N;j++)
						 {
							 tempTree[tmpT_counter][j]=ParaMint.DMatrix[tmpT_counter][j]; 	 // Copy optimal solution to Remaining[Acorn +Normal] tree
						 }
						tmpT_counter++;
					 }
				}
			  HT_counter=0;tmpT_counter=0;
				tempTree=sorted(tempTree);

				// Traverse Contents of each Tree.
				System.out.println("Squirrel to HT "+ParaMint.GREEN+ "[ "+ParaMint.suite+" ]"+ParaMint.ANSI_RESET);
				for(int i=0;i<ParaMint.N_HNT;i++) {
					FS_HNT_FIT = Objective_Function.func(ParaMint.tmpFS_HNT[i]);
					    System.out.println("\t\t=> " + Arrays.toString(ParaMint.tmpFS_HNT[i]) + "  " + ParaMint.to.format(FS_HNT_FIT[0]));
				}

				System.out.println("Squirrel to AT");
			    for(int i=0;i<ParaMint.N_ANT;i++){
					for(int j=0;j<ParaMint.N;j++) {
						ParaMint.tmpFS_ANT[i][j]=tempTree[i][j];
					}
					   FS_ANT_FIT= Objective_Function.func(ParaMint.tmpFS_ANT[i]);
									 System.out.println("\t\t=> "+Arrays.toString(ParaMint.tmpFS_ANT[i])+"  "+ParaMint.to.format(FS_ANT_FIT[0]));
				}


            	System.out.println("Squirrel to NT");
				for(int i=0;i<ParaMint.N_NORMT;i++){
					for(int j=0;j<ParaMint.N;j++) {
						ParaMint.tmpFS_NORMT[i][j]=tempTree[ParaMint.N_ANT+i][j];	// Assign squirrel to Normal tree
					}
					FS_NORMT_FIT= Objective_Function.func(ParaMint.tmpFS_NORMT[i]);
								System.out.println("\t\t=> "+Arrays.toString(ParaMint.tmpFS_NORMT[i])+"   "+ParaMint.to.format(FS_NORMT_FIT[0]));
				}

			}


			// Method to display the content of the solution

			public void toStringnew(){
					this.solution();
//					line();
//					DisplayOptimalSolution();
//					line();
					iDIMFitCost();
					line();
					optimalTestSuite();
					line();
					iterationInfo();
					line();
					ParaMint.NoTcase="";
					}
}



         







 