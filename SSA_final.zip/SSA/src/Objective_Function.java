import java.util.Random;

public class Objective_Function {

    public Objective_Function(){}
    public static double[] func(double[] fs_hnt) {
        double check = 0,no_killed_mutant,no_total_mutants;
        double mutation_score=0.0D,m_score_compliment=0.0D;
        int i=0,Pyes=0,PTmutant=0;
        double [] yy=new double [fs_hnt.length];
        while(i<fs_hnt.length)
        {
            yy[i]=fs_hnt[i];
            if(yy[i]==1){
                Pyes++;
                PTmutant++;}
            if (yy[i]== 0) {
                PTmutant++;
            }
            i++;}
        Random r = new Random();
        double randomValue = 0 + (1 - 0.0D) * r.nextDouble();
        no_total_mutants=PTmutant;no_killed_mutant=Pyes;
        if (no_total_mutants!=check)
        {
            mutation_score =((((no_killed_mutant)/(no_total_mutants))*100)+ randomValue);
            m_score_compliment=100-mutation_score;

        }
        return (new double[]{mutation_score, m_score_compliment,Pyes,PTmutant});
    }


}