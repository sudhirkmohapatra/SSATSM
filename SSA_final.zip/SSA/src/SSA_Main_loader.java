 
public class SSA_Main_loader {
    private final int maxiter;
    private final int iLower;
    private final int iUpper;
    private final int N;
    private final int D;
    private SSA_Main_loader(){
        try {
            problem.main123();
        } catch (Exception e) { e.printStackTrace(); }
        this.maxiter=100; this.iLower=0;this.iUpper=1;
        this.N = problem.constraints.length;
        this.D = problem.constraints[0].length;
//        System.out.println("N => "+N+"  D=> "+D);
    }

    private void init(){new ParaMint(N,D, iLower, iUpper, this.maxiter); }

    public static void main(String args[])
     {
        SSA_Main_loader loader = new SSA_Main_loader();

        for (int i=0; i<5;i++)
         {
            System.out.println("\t\t\t "+problem.name+" "+(i+1));
            System.out.println("=====++++++++++++++++++++++++++++=======\n");
            ParaMint.initialTime = System.currentTimeMillis();
            loader.init();
            (new SSAiPhase()).toStringnew();
            System.out.println(ParaMint.ANSI_BLUE+"Execution time: " + (String.valueOf((ParaMint.elapseTime - ParaMint.initialTime) / 1000.0)) + "s.");
            System.out.println("TotalIteration " + ParaMint.Maxiter);
            System.out.println(ParaMint.ANSI_RESET+"=====++++++++++++++++++++++++++++=======");
        }

     }
}